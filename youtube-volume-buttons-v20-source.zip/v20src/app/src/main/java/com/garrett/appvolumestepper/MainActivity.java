package com.garrett.appvolumestepper;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity implements SamsungAppVolumeManager.Listener {
    private SamsungAppVolumeManager manager;
    private TextView status;
    private TextView level;
    private TextView error;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        manager = App.get().manager();

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(22), dp(22), dp(28));

        page.addView(text("YouTube Volume Buttons v2.0", 28, Color.rgb(20, 20, 20)), matchWrap(dp(10)));
        page.addView(text(
                "This version uses Samsung's own per-app volume API. It changes the SAME YouTube percentage shown by Sound Assistant — not a second hidden gain and not the main Media volume.",
                16,
                Color.rgb(45, 45, 45)
        ), matchWrap(dp(18)));

        status = text("", 17, Color.rgb(25, 25, 25));
        page.addView(status, matchWrap(dp(8)));

        level = text("", 21, Color.rgb(20, 20, 20));
        level.setGravity(Gravity.CENTER_HORIZONTAL);
        page.addView(level, matchWrap(dp(16)));

        Button permission = button("Request / refresh Shizuku permission");
        permission.setOnClickListener(v -> manager.requestPermission());
        page.addView(permission, matchWrap(dp(8)));

        Button shizuku = button("Open Shizuku");
        shizuku.setOnClickListener(v -> {
            Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (launch != null) startActivity(launch);
        });
        page.addView(shizuku, matchWrap(dp(8)));

        Button accessibility = button("Enable physical volume-button service");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        page.addView(accessibility, matchWrap(dp(16)));

        LinearLayout tests = new LinearLayout(this);
        tests.setOrientation(LinearLayout.HORIZONTAL);
        Button minus = button("Test −1%");
        Button plus = button("Test +1%");
        minus.setOnClickListener(v -> manager.step(-1));
        plus.setOnClickListener(v -> manager.step(1));
        tests.addView(minus, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        tests.addView(plus, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        page.addView(tests, matchWrap(dp(18)));

        page.addView(text(
                "How it works: while YouTube is the foreground app, Volume Up/Down changes Samsung's native YouTube app-volume by exactly 1 percentage point. A small YouTube volume popup appears on every press, including while the video is playing. In other apps, the buttons stay normal.",
                15,
                Color.rgb(60, 60, 60)
        ), matchWrap(dp(14)));

        page.addView(text(
                "You can confirm it by opening Sound Assistant's expanded panel: its YouTube slider should match the percentage shown here.",
                15,
                Color.rgb(60, 60, 60)
        ), matchWrap(dp(14)));

        error = text("", 13, Color.rgb(155, 20, 20));
        page.addView(error, matchWrap(0));

        setContentView(page);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        manager.addListener(this);
        manager.refreshPercent();
        render();
    }

    @Override
    protected void onPause() {
        manager.removeListener(this);
        super.onPause();
    }

    @Override
    public void onChanged() {
        runOnUiThread(this::render);
    }

    private void render() {
        String s;
        switch (manager.getStatus()) {
            case NOT_SAMSUNG: s = "Samsung native app-volume API: this is not a Samsung device"; break;
            case YOUTUBE_MISSING: s = "Samsung native app-volume API: YouTube not found"; break;
            case SHIZUKU_MISSING: s = "Shizuku: not installed"; break;
            case SHIZUKU_STOPPED: s = "Shizuku: installed but not running"; break;
            case PERMISSION_NEEDED: s = "Shizuku: permission needed"; break;
            case READY: s = "Samsung native app-volume API: READY"; break;
            default: s = "Samsung native app-volume API: ERROR"; break;
        }
        status.setText(s);

        int p = manager.getLastKnownPercent();
        level.setText(p >= 0 ? "YouTube Sound Assistant volume: " + p + "%" : "YouTube Sound Assistant volume: —");

        String e = manager.getLastError();
        error.setText(e == null || e.isEmpty() ? "" : e);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }

    private TextView text(String value, float sp, int color) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setLineSpacing(dp(2), 1f);
        return v;
    }

    private LinearLayout.LayoutParams matchWrap(int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        p.bottomMargin = bottom;
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
