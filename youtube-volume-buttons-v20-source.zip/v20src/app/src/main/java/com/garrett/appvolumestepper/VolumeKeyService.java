package com.garrett.appvolumestepper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class VolumeKeyService extends AccessibilityService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String lastForegroundPackage = "";
    private int consumedKeyCode = KeyEvent.KEYCODE_UNKNOWN;

    private WindowManager windowManager;
    private LinearLayout popup;
    private TextView popupText;
    private ProgressBar popupProgress;
    private final Runnable hidePopup = () -> {
        if (popup != null) popup.setVisibility(View.GONE);
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
            setServiceInfo(info);
        }
        createPopup();
        App.get().manager().refreshPercent();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if (pkg.equals(getPackageName()) || isTransientSystemPackage(pkg)) return;
        lastForegroundPackage = pkg;
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        int keyCode = event.getKeyCode();
        if (keyCode != KeyEvent.KEYCODE_VOLUME_UP && keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false;
        }

        if (event.getAction() == KeyEvent.ACTION_UP) {
            if (consumedKeyCode == keyCode) {
                consumedKeyCode = KeyEvent.KEYCODE_UNKNOWN;
                return true;
            }
            return false;
        }

        if (event.getAction() != KeyEvent.ACTION_DOWN || !isYouTubeForeground()) return false;

        SamsungAppVolumeManager manager = App.get().manager();
        if (!manager.isReady()) return false;

        int value = manager.step(keyCode == KeyEvent.KEYCODE_VOLUME_UP ? 1 : -1);
        if (value < 0) return false;

        consumedKeyCode = keyCode;
        showPopup(value);
        return true;
    }

    private boolean isYouTubeForeground() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null && root.getPackageName() != null) {
                String pkg = root.getPackageName().toString();
                root.recycle();
                if (SamsungAppVolumeManager.YOUTUBE.equals(pkg)) {
                    lastForegroundPackage = pkg;
                    return true;
                }
                if (!isTransientSystemPackage(pkg) && !pkg.equals(getPackageName())) {
                    lastForegroundPackage = pkg;
                }
            }
        } catch (Throwable ignored) {
        }
        return SamsungAppVolumeManager.YOUTUBE.equals(lastForegroundPackage);
    }

    private boolean isTransientSystemPackage(String pkg) {
        return "com.android.systemui".equals(pkg)
                || "com.samsung.android.soundassistant".equals(pkg)
                || "com.samsung.android.app.soundassistant".equals(pkg);
    }

    private void createPopup() {
        if (popup != null) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12), dp(10), dp(14), dp(10));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(235, 38, 38, 42));
        bg.setCornerRadius(dp(18));
        card.setBackground(bg);

        ImageView icon = new ImageView(this);
        try {
            icon.setImageDrawable(getPackageManager().getApplicationIcon(SamsungAppVolumeManager.YOUTUBE));
        } catch (Throwable ignored) {
        }
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(34), dp(34));
        iconParams.rightMargin = dp(10);
        card.addView(icon, iconParams);

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);

        popupText = new TextView(this);
        popupText.setTextColor(Color.WHITE);
        popupText.setTextSize(16);
        popupText.setSingleLine(true);
        right.addView(popupText, new LinearLayout.LayoutParams(dp(160), dp(24)));

        popupProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        popupProgress.setMax(100);
        right.addView(popupProgress, new LinearLayout.LayoutParams(dp(160), dp(8)));

        card.addView(right);
        card.setVisibility(View.GONE);
        popup = card;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                android.graphics.PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = dp(14);
        params.y = dp(74);
        windowManager.addView(card, params);
    }

    private void showPopup(int percent) {
        if (popup == null) createPopup();
        if (popup == null) return;
        popupText.setText("YouTube  " + percent + "%");
        popupProgress.setProgress(percent);
        popup.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hidePopup);
        handler.postDelayed(hidePopup, 1400);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(hidePopup);
        if (windowManager != null && popup != null) {
            try {
                windowManager.removeView(popup);
            } catch (Throwable ignored) {
            }
        }
        popup = null;
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
