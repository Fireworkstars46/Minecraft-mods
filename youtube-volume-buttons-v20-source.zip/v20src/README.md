# YouTube Volume Buttons v2.0

Samsung-specific build that redirects physical volume keys to Samsung's native per-app volume for YouTube.

Key changes from v1.9:
- Uses Samsung `AudioManager.getAppVolume(uid)` / `setAppVolume(uid, ratio)` hidden framework APIs through Shizuku.
- Adjusts the same 0-100 per-app percentage used by Sound Assistant.
- Does not scan, open, click, or gesture on Samsung's volume panel.
- Does not use `IPlayer.setVolume`, so there is no separate hidden YouTube gain.
- Intercepts volume keys whenever YouTube is the foreground app, not based on playback-state guessing.
- Shows its own compact YouTube percentage popup on every successful hardware-button press, including during playback.
- Falls back to normal Android volume behavior if the Samsung native call fails.
